package mukilan.problem_statement_9;

import java.util.Scanner;

public class Find_Frequency {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int arr[] = {2,2,2,4,4,4,5,5,6,8,8,9};
		int len = arr.length;
		int i,j,count = 0;
		for(i=0;i<len;i++) {
			count = 0;
			for(j=0;j<len;j++) {
				if(arr[i] == arr[j] ) {
					count++;
				}
			}
			System.out.println(arr[i] + " occurs " + count + " times");
		}
	}

}
