package mukilan.problem_statement_2_3;

import java.util.Scanner;

public class App {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int sum = 0;
		int A[] = {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
		int len = A.length;
		int i,value=0;
		for(i=0; i<=14;i++) {
			sum = sum + A[i];
		}
		System.out.println("Sum of first 14 indexes : " + sum);
		A[15] = sum;
		for(i=0 ;i<len;i++)
		System.out.print(A[i] + " ");
		
		for(i=0; i<len; i++) {
			value = value + A[i];
		}
		int avg = value/len;
		System.out.println("\n");
		System.out.println("Average of the Array = " + avg);
		
		A[16] = avg;
		for(i=0 ;i<len;i++)
		System.out.print(A[i] + " ");
		
		int min = A[1];
		for(i=0;i<len;i++) {
		if(A[i]<min) {
			min = A[i];
		}
		}
		System.out.println("\n");
		System.out.println("Minimum Element in Array : " + min);
		
		A[17] = min;
		for(i=0 ;i<len;i++)
		System.out.print(A[i] + " ");
	}

}
