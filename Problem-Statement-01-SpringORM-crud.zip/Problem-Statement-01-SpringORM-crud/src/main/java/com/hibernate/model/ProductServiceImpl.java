package com.hibernate.model;

public interface ProductServiceImpl {

	int getId();

	void setId(int id);

	String getName();

	void setName(String name);

	double getPrice();

	void setPrice(String price);

	int getQuantity();

	void setQuantity(String quantity);

}